package emailer;

import java.util.ArrayList;
import java.io.Console;

public class Arr {
	//create arraylist instance
	ArrayList<person> arr= new ArrayList<person>();
	//create getter unnecessary
	public Arr() {}

	public ArrayList<person> getList(){
		return this.arr;
	}
	
}
