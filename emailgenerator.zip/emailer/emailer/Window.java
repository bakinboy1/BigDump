package emailer;

import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import javax.swing.DefaultListModel;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JList;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.SwingConstants;
import java.awt.Font;


public class Window extends JFrame {

	private JPanel contentPane;

	/**
	 * Launch the application.
	 */
	

	/**
	 * Create the frame.
	 */
	
	
	DefaultListModel<person> listModel= new DefaultListModel<>();
	
	public Window() {
		
		
		JList<person> list = new JList<person>(listModel);
		
		
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		contentPane.setLayout(new BorderLayout(0, 0));
		setContentPane(contentPane);
		getContentPane().setLayout(new BorderLayout(0, 0));
		
		JButton button = new JButton("Generate Email");
		button.setFont(new Font("Tahoma", Font.PLAIN, 12));
		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
			}
		});
		getContentPane().add(button, BorderLayout.SOUTH);
		JScrollPane scrollPane = new JScrollPane(list);
		getContentPane().add(scrollPane, BorderLayout.CENTER);
		
		JLabel lblSelectPeople = new JLabel("Select Person(s)");
		lblSelectPeople.setFont(new Font("Tahoma", Font.PLAIN, 12));
		lblSelectPeople.setHorizontalAlignment(SwingConstants.CENTER);
		scrollPane.setColumnHeaderView(lblSelectPeople);
	}
	
	//needs to be variable 'a' from Main class
	for(int i=0; i<a.getList().size(); i++) {
		listModel.addElement(a.getList().get(i));
	}
		
	public static void run() {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Window frame = new Window();
					
					frame.setVisible(true);
					frame.getContentPane().setSize(800,400);
					frame.setBounds(200, 50, 630, 500);
					
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});	
	}

}
///////////
