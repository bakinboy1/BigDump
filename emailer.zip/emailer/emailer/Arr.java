package emailer;

import java.util.ArrayList;


public class Arr {
	//create arraylist instance
	ArrayList<person> arr= new ArrayList<person>();
	//create getter unnecessary
	public Arr() {
	}

	public ArrayList<person> getList(){
		return arr;
	}

	
}
