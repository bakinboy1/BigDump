package emailer;

import javax.swing.DefaultListModel;

public class Model {
	DefaultListModel<person> listModel= new DefaultListModel<>();
public Model() {}

public void setModel(DefaultListModel<person> listModel) {
	this.listModel=listModel;
	
}
public DefaultListModel<person> getModel() {
	return listModel;
}

}
