//fabian hucke
//8/31/2017

#include <stdio.h>
#include <math.h>
//int main(int argc, char* argv[] ){
int main(){
//initial loan
double loan=0;
//loan + interest
double newLoan=0;
//interest rate
double r=0;
//years
int t=0;
//payments per year
int payment=0;
//monthly payment
double m=0;
// total # of payments to be made
int z=0;
//interest paid
double interest=0;
//principle
double principle=0;
//temp
double temp=0;
//set variables----change to take command-line input later
loan=10000.00;
r=0.06;
t=5;
payment=12;

//total # of payments to be made
z=t*payment;
//number of payments in a year
temp=r/payment;

m=loan*(temp+(temp/(pow((1+temp),(payment*t))-1)));
//monthly payment calculation= loan amount/
 



printf("Amortization Schedule\n");
printf("Initial Balance: %.2f\n", loan);
printf("APR: %.2f\n", r);
printf("Years: %d\n\n", t);
printf("Monthly Payment: $%.2f\n", m);
printf("Month		Int.		Princ.		Balance\n");
for (int i=1; i<z; ++i){
//interest rate * loan + previous loan amount
newLoan=loan*temp + loan;
//newLoan-loan to get interest paid
interest=newLoan-loan;
//monthly payment - interest paid to get principle
principle=m-interest;
//newLoan - monthly payment = new loan balance
loan=newLoan-m;
//calculate if m exceeds remaining debt balance
if (m>loan && loan>0.00){
	m=m-loan;
	
	return printf("%d		$%.2f		$%.2f		$%.2f\n",i,interest,principle,loan);

}
else{
	
	return printf("%d 		$%.2f 		$%.2f 	$%.2f",i,interest,principle,loan);
} 

}


return 0;
}