
/**
 * Write a description of class Main here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Main
{
    public static void main(String[] args){
        int[] array = {1,2,3,5,7,9,55,44,3,4,6,77};
        System.out.println(iteration(array));
        System.out.println(recursive(array,11));
        
    }
    
    public static int iteration(int[]array){
        
        int sum =0;
        for (int n:array){
            sum+=n;
        }
        return sum;
    }

    public static int recursive(int[]array, int n) {
        if (n == 0){
            return array[n];
        }
        else{
            return array[n] + recursive(array, n-1);
        }

    }

}

