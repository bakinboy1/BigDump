import java.util.*;
import java.io.*;
/**
 * Write a description of class FileWordCounter here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class FileWordCounter
{
    //word class seems unneccessary using this methodology
    public static void main(String args[]){
        //how to get java to read text from file?
        //user inputs file name

        Scanner input = new Scanner(System.in);
        String userChoice="1";
        String filename = "properkjv.txt";

        while (!(userChoice.equals("exit"))){
            System.out.println("Enter one of the following 3 files to read the wordcount from or type 'exit' to exit");
            System.out.println("properkjv.txt   properkjv0.txt   properkjv1.txt");
            userChoice=input.nextLine();

            if(userChoice.equals("properkjv.txt")){
                filename="properkjv.txt";
            }
            else if(userChoice.equals("properkjv0.txt")){
                filename="properkjv0.txt";
            }
            else if(userChoice.equals("properkjv1.txt")){
                filename="properkjv1.txt";
            }
            else if (userChoice.equals("exit")){
                System.exit(0);
            }
            else{

                System.out.println("you must enter one of the three file names");
                userChoice= input.nextLine();
            }

            String records="";
            try{
                BufferedReader reader = new BufferedReader(new FileReader(filename));

                String line;
                while ((line = reader.readLine()) != null)
                {
                    records+=line;
                }
            }
            catch (Exception e)
            {
                System.err.format("Exception occurred trying to read '%s'.", filename);
                e.printStackTrace();

            }
            String text=records;
            String textLower=text.toLowerCase();

            //what does split do?
            //.split seperates strings into different strings each time it identifies a split char
            //found list of sybols to split
            String text2[]=textLower.split(" ");
            HashMap<String, Integer> wordCount= new HashMap<String, Integer>();

            //trying (int word = 0; word<text2.length; word++) just returns error at 
            //wordCount.put(word, (int word = 0; word<text2.length; word++));

            // cant really use for loops as parameter vars.
            //put shorthand instead currentCount==null ? 1 : (currentCount +1)

            // Why cant this find currentCount as its own method?
            //   public int bork(){
            //if(currentCount==null){
            //    currentCount=1;
            //}
            //    else{
            //        currentCount ++;
            //    }
            //}

            //everything online is saying to use a 'condensed fucntion'???
            //http://stackoverflow.com/questions/2399590/java-what-does-the-colon-operator-do
            //http://stackoverflow.com/questions/10336899/what-is-a-question-mark-and-colon-operator-used-for
            // to get wordCount.put(word, (currentCount==null ? 1 : (currentCount +1)));
            // to work.
            //using enhanced for loop necessary
            //for( each String word : in text2)
            //condensed fucntions are a godsend!!!!!

            for (String word : text2 ){
                Integer currentCount=wordCount.get(word);

                //nvm, condensed into currentCount==null ? 1 : (currentCount +1)
                //http://www.terminally-incoherent.com/blog/2006/04/21/java-operator/
                //why is this the only way to use an if/else statement inside a method param?
                //maybe not, but definately the most logical/straightforward way to do this.

                //use .put to add elements to hash table/map

                //adds a  counter for each word found
                // if currentCount == null
                // currentCount ==1
                //else currentcount +1 
                wordCount.put(word, (currentCount==null ? 1 : (currentCount +1)));
            }
            //create set of words and their frequency
            //entrySet sets an entry
            Set<Map.Entry<String, Integer>> sets= wordCount.entrySet();

            //print out all words &their frequencies
            //how to order so that largest entry.getValue() gets printed out first?
            //getValue max function? 
            //increment 0 to max then reverse?

            //use Collections.sort
            //how to get it to sort by the Integer?
            //sort the hashmap 
            //http://stackoverflow.com/questions/109383/sort-a-mapkey-value-by-values-java
            // for each 'entry' in 'sets'
            // do if statement

            //move hashmap into arraylist to use comparator
            ArrayList<Word> list = new ArrayList<Word>();
            for(Map.Entry<String, Integer> entry : sets){
                //Collections.sort(list, getCount());

                if(entry.getValue() > 0){
                    list.add(new Word(entry.getKey(), entry.getValue()));

                }
            }
            Collections.sort(list, new CompareFreq());
            for( int i = 0; i < list.size(); i++){
                System.out.println(list.get(i));
            }
            //http://stackoverflow.com/questions/2885173/how-to-create-a-file-and-write-to-a-file-in-java
            Date date= new Date();
            try{
                PrintWriter writer = new PrintWriter(filename+date.getTime()+".txt", "UTF-8");
                for( int i = 0; i < list.size(); i++){
                    writer.println(list.get(i));
                }

                writer.close();
            } catch (IOException e) {
                System.err.format("Exception occurred trying to read '%s'.", filename);
                e.printStackTrace();
            }
        }
    }

}
