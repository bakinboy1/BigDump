
/**
 * Read data from a file
 * 
 * @author Radhouane
 * @version 4/22/2016
 */
import java.util.*;
//import java.io.File;
//import java.io.FileNotFoundException;
import java.io.*;

public class ReadFromFile
{
    public static void main(String[] arg) throws FileNotFoundException
    {
         
        ArrayList<Integer> data = new ArrayList<Integer>();
        //try-catch blocks for exception handling
        try{
            //Set up a file object
            File myFile = new File("contacts.txt");
            //Set up a scanner for that file 
             Scanner input= new Scanner(myFile);
        String userChoice= input.nextLine();
            

            while(input.hasNext()){
                int value = Integer.parseInt(input.nextLine());     
                System.out.println(value);
                //Add that value to the array list
                data.add(value);
            }

        } catch(IOException e){
            System.out.println("The file called contacts was nout found!!");
        }

        for(int i = 0; i < data.size(); i++){
            System.out.println(data.get(i));
        }
        //Sort the array list

        for(int bubble = 1; bubble <=data.size(); bubble++){

            for(int i = 0; i < data.size()-1; i++){
                if(data.get(i)>data.get(i+1)){
                    Integer temp = data.get(i);
                    data.set(i, data.get(i+1));
                    data.set(i+1, temp);
                }
            }
        }
        File myFile = new File("contacts.txt");
        Scanner input= new Scanner(myFile);
        String userChoice= input.nextLine();
        System.out.println("Which one to remove?");
        int choice = Integer.parseInt(userChoice.nextLine());
        data.remove(choice);
        data.remove(choice+1);
        data.remove(choice+2);
        data.remove(choice+3);
        data.remove(choice+4);
        data.remove(choice+5);
        
        
        //Saving the data
        PrintWriter myWriter = new PrintWriter("contacts.txt");

        for(int i = 0; i < data.size(); i++){
            myWriter.println(data.get(i));
        }

        myWriter.close();

    }
}
