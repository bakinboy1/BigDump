
/**
 * Write a description of class Tester here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Tester
{
 
    //YOUTUBE VIDEO LINK: https://www.youtube.com/watch?v=HpjbqrL4XXc&feature=youtu.be
    
 public static void main (String args[]){
    //create a linkedStack integer object
    // push 3 int values
    //pop the top element and print
    //create for loop to print all elements
    Queue2Stack<Integer> link= new Queue2Stack<Integer>();
    link.enqueue(3);
    link.enqueue(4);
    link.enqueue(5);
    link.enqueue(12);
    link.enqueue(20);
    
    
    }
}
