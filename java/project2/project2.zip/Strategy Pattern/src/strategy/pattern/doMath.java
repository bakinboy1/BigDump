/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package strategy.pattern;

/**
 *
 * @author fabian
 */
//the interface that all the classes use.
//each calculator class implements this arguement in different ways
 interface doMath
{
    public double doMath(double v1, double v2);
}
