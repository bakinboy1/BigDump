/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package strategy.pattern;

/**
 *
 * @author fabian
 */
public class Add implements doMath
{
  @Override
public double doMath(double v1, double v2){
double answer=v1+v2;
return answer;
}
}
