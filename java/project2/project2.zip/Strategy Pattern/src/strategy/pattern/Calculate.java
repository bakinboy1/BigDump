/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package strategy.pattern;

/**
 *
 * @author fabian
 */
// refers to the interface instance to perform an algorithm
public class Calculate {
    
    private doMath math;
    public Calculate(doMath type){
        this.math= type;
    }
    public double go(double v1, double v2){
        return math.doMath(v1, v2);
    }
}
